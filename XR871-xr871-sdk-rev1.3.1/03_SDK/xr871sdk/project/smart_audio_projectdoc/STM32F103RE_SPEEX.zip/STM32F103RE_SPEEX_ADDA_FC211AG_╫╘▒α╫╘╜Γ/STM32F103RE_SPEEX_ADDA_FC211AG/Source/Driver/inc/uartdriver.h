/*
 * ========================================================================
 *
 *       Filename:  uartdriver.h
 *
 *    Description:  
 *
 *        Version:  1.0.0
 *        Created:  2011.11.16
 *       Revision:  none
 *       Compiler:  IAR 6.01
 *            Cpu:  STM32F103RET6
 *
 *         Author:  ������ (adi)
 *          Email:  wangzengdi@gmail.com  
 *             QQ:  506064082
 *
 * ========================================================================
 */
#ifndef  UARTDRIVER_H
#define  UARTDRIVER_H

#define UARTRXBUFFERLENGTH  0xFF
#define UARTTXBUFFERLENGTH  0xFF

typedef struct
{
  volatile uint8_t RxBuffer[UARTRXBUFFERLENGTH + 1];
  volatile uint8_t TxBuffer[UARTTXBUFFERLENGTH + 1];
  uint16_t RxIn;
  uint16_t RxOut;
  uint16_t TxIn;
  uint16_t TxOut; 
  volatile uint16_t TxBusy;
  volatile uint32_t Rx_Counter;
  volatile uint32_t Tx_Counter;  
  volatile uint16_t RxCountinue;
  volatile uint16_t TxCountinue;
}UARTTYPEDEF;

extern UARTTYPEDEF Uart2;

void USART_Baudrate_Set(USART_TypeDef* USARTx,uint32_t Baudrate);
void PutStringToUart1(unsigned char *p,unsigned char Num);
void PutStringToUart1Continue(unsigned char *p);
void PutStringToUart2(unsigned char *p,unsigned char Num);

#endif
