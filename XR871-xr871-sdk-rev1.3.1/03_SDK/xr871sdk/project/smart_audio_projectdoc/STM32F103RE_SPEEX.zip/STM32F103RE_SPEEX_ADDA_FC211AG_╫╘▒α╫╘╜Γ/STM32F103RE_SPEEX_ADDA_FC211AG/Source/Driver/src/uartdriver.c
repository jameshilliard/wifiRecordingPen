/*
 * ========================================================================
 *
 *       Filename:  uartdriver.c
 *
 *    Description:  
 *
 *        Version:  1.0.0
 *        Created:  2011.11.16
 *       Revision:  none
 *       Compiler:  IAR 6.01
 *            Cpu:  STM32F103RET6
 *
 *         Author:  ������ (adi)
 *          Email:  wangzengdi@gmail.com  
 *             QQ:  506064082
 *
 * ========================================================================
 */

#include "stm32_includes.h"

UARTTYPEDEF Uart1;
UARTTYPEDEF Uart2;
//UART Uart1;
void PutStringToUart1(unsigned char *p,unsigned char Num)
{
  while(Num--)
  {
    Uart1.TxBuffer[Uart1.TxIn] = *p;
    p++;
    Uart1.TxIn = (Uart1.TxIn + 1)&UARTTXBUFFERLENGTH;
  }
  if(Uart1.TxBusy == 0)
  {
  USART_ITConfig(USART1, USART_IT_TXE, ENABLE);  
  Uart1.TxBusy = 1;
  }
}
void PutStringToUart1Continue(unsigned char *p)
{
  while((*p)!= 0)
  {
    Uart1.TxBuffer[Uart1.TxIn] = *p;
    p++;
    Uart1.TxIn = (Uart1.TxIn + 1)&UARTTXBUFFERLENGTH;
  }
  if(Uart1.TxBusy == 0)
  {
  USART_ITConfig(USART1, USART_IT_TXE, ENABLE);  
  Uart1.TxBusy = 1;
  }
   while(Uart1.TxBusy);
}
void PutOneCharToUart1(u8 Num)
{

  Uart1.TxBuffer[Uart1.TxIn] = Num;
  Uart1.TxIn = (Uart1.TxIn + 1)&UARTTXBUFFERLENGTH;
  
  if(Uart1.TxBusy == 0)
  {
  USART_ITConfig(USART1, USART_IT_TXE, ENABLE);  
  Uart1.TxBusy = 1;
  }
}
//=======================================================

//USART2
void PutStringToUart2(unsigned char *p,unsigned char Num)
{
  while(Num--)
  {
    Uart2.TxBuffer[Uart2.TxIn] = *p++;
//    p++;
    Uart2.TxIn = (Uart2.TxIn + 1)&UARTTXBUFFERLENGTH;
  }
  if(Uart2.TxBusy == 0)
  {
  USART_ITConfig(USART2, USART_IT_TXE, ENABLE);  
  Uart2.TxBusy = 1;
  }
}
void PutOneCharToUart2(u8 Num)
{
  {
    Uart2.TxBuffer[Uart2.TxIn] = Num;
    Uart2.TxIn = (Uart2.TxIn + 1)&UARTTXBUFFERLENGTH;
  }
  if(Uart2.TxBusy == 0)
  {
  USART_ITConfig(USART2, USART_IT_TXE, ENABLE);  
  Uart2.TxBusy = 1;
  }
}

//coder and decoder work
void USART_Baudrate_Set(USART_TypeDef* USARTx,uint32_t Baudrate)
{
  USART_Cmd(USARTx, DISABLE);
  USART_InitTypeDef USART_InitStructure;
  USART_ClockInitTypeDef USART_ClockIni;
  
  USART_InitStructure.USART_BaudRate = Baudrate;
  USART_InitStructure.USART_WordLength = USART_WordLength_8b;
  USART_InitStructure.USART_StopBits = USART_StopBits_1;
  USART_InitStructure.USART_Parity = USART_Parity_No;
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
  
  USART_ClockIni.USART_Clock = USART_Clock_Disable;
  USART_ClockIni.USART_CPOL = USART_CPOL_Low;
  USART_ClockIni.USART_CPHA = USART_CPHA_2Edge;
  USART_ClockIni.USART_LastBit = USART_LastBit_Disable;


  /* USART configuration */
  USART_Init(USARTx, &USART_InitStructure);
  USART_ClockInit(USARTx,&USART_ClockIni);
  USART_ITConfig(USARTx, USART_IT_RXNE, ENABLE);
//  USART_ITConfig(USART3, USART_IT_TXE, DISABLE);//
  USART_Cmd(USARTx, ENABLE);
}