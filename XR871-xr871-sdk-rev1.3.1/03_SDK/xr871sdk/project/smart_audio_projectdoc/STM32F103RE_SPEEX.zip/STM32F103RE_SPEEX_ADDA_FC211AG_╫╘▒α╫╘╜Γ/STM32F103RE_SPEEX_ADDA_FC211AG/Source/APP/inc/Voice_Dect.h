/*
 * ========================================================================
 *
 *       Filename:  Voice_Dect.h
 *
 *    Description:  
 *
 *        Version:  1.0.0
 *        Created:  2011.11.23
 *       Revision:  none
 *       Compiler:  IAR 6.01
 *            Cpu:  STM32F103RET6
 *
 *         Author:  ������ (adi)
 *          Email:  wangzengdi@gmail.com  
 *             QQ:  506064082
 *
 * ========================================================================
 */

#ifndef _Voice_Dect_h
#define _Voice_Dect_h

int32_t sum_all(int16_t *ptr, int16_t len);

int32_t aver(int16_t *ptr, int16_t len);

uint32_t aver_abs(int16_t *ptr, int16_t len);

void clear_all(int16_t *ptr, int16_t len);

void suppress_all(int16_t *ptr, int16_t len);

#define ABS_SUB(a, b) ((a>b)?(a-b):(b-a))

#endif

