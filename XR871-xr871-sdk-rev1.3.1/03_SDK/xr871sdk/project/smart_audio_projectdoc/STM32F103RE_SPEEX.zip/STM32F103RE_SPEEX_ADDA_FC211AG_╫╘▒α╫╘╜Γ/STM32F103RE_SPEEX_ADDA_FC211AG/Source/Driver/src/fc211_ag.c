/*
 * ========================================================================
 *
 *       Filename:  fc211_ag.c
 *
 *    Description:  
 *
 *        Version:  1.0.0
 *        Created:  2011.11.16
 *       Revision:  none
 *       Compiler:  IAR 6.01
 *            Cpu:  STM32F103RET6
 *
 *         Author:  ������ (adi)
 *          Email:  wangzengdi@gmail.com  
 *             QQ:  506064082
 *
 * ========================================================================
 */

#include "stm32_includes.h"
#define TX_PLOAD_WIDTH  20  	// 20 uints TX payload
#define RX_PLOAD_WIDTH  20  	// 20 uints TX payload
#include "fc211_ag.h"

TRBUFFER trbuffer; 

//void packhead(void);
//***********************************************************************************************************
//*������void Packet_send(char * out,uint16_t num)
//*���ܣ����� tx_buf������
//**********************************************************************************************************/

//��װ�������ͷ------------------------------------------------------------

void Delayms(unsigned int counter)
{
  unsigned int i;
  unsigned int j;
  while(counter>0)
  {
    for(j=0;j<50;j ++)
    {
      for(i=0;i<10;i ++);
    }
    counter--;    
  } 
}



void FC211_AG_Init(void)
{
  unsigned char ChannelSetOK=0;
// unsigned char sum=0; 
  unsigned char temp;
  unsigned char step;
// unsigned long crctemp=0;
 
  unsigned char SetChannel_480Cmd[10]={0x55,0xAA,0x06,0x07,0x00,0x00,0x00,0x00,0x00,0x00};
  unsigned char SetSkyBaudrate_480Cmd[8]={0x55,0xAA,0x04,0x20,0x05,0x80,0X00,0xA9};
  unsigned char SetUartBaudrate_480Cmd[7]={0x55,0xAA,0x03,0x28,0x05,0x00,0x30};
  unsigned char ReadChannel_480Cmd[7]={0x55,0xAA,0x03,0x24,0x00,0x00,0x27};
  unsigned char ReadSkyBaudrate_480Cmd[7]={0x55,0xAA,0x03,0x23,0x00,0x00,0x26};
//  unsigned char SetUartBaudrate_480Cmd[7]={0x55,0xAA,0x03,0x28,0x06,0x00,0x31};

  
  SetChannel_480Cmd[4] = 0x01;
  SetChannel_480Cmd[9] = 0x06+0x07+0x01;
  Delayms(100);
  PutStringToUart2(SetChannel_480Cmd,10);
  Delayms(1000);
//  PutStringToUart2(SetSkyBaudrate_480Cmd,8);
  Delayms(100);
//  PutStringToUart2(SetUartBaudrate_480Cmd,7);
  Delayms(100);
//  USART_Baudrate_Set(USART2,38400);
  Delayms(50);
  PutStringToUart2(ReadChannel_480Cmd,7);
  Delayms(1000);
  PutStringToUart2(ReadSkyBaudrate_480Cmd,7);  
  Delayms(1000);
  ChannelSetOK=0;
  step=0;
  while(Uart2.RxOut != Uart2.RxIn)//����û�в�ѯ��ͷ
	{ 
	  temp = Uart2.RxBuffer[Uart2.RxOut];
	  Uart2.RxOut = (Uart2.RxOut + 1) & UARTRXBUFFERLENGTH;
   	  switch(step)
	  {
		case 0:if(temp==0x55)  step=1;else step=0;break;  //
		case 1:if(temp==0xAA)  step=2;else if(temp==0x55)  step=1;else step=0;break;  //
		case 2:if(temp==0x02||temp==0x0B)  step=3;else step=0;break;  
		case 3:if(temp==0x20||temp==0x55)  step=4;		  // 0x20-480M��ȷӦ��;  0x55-433M��ȷӦ��
				else  {ChannelSetOK=0; step=0;}break; // 0x21-480M����Ӧ��;��0x55-433M����Ӧ��
		case 4:if(temp==0x01) {ChannelSetOK=1; step=0;}break;  //	 
	    
	  default :step=0;break;
	  }
	}
}

void packhead(void)  
{
// trbuffer.tbuffer[0]=0x55;
 trbuffer.tbuffer[0]=0x55;
 trbuffer.tbuffer[1]='A';
 trbuffer.tbuffer[2]='D';
 trbuffer.tbuffer[3]='I';
// trbuffer.tbuffer[4]=RecordTemp.Ad1;//��ַ����ֽ�
// trbuffer.tbuffer[5]=RecordTemp.Ad2;//��ַ�м��ֽ�
// trbuffer.tbuffer[6]=RecordTemp.Ad3;//��ַ����ֽ�
}

void Packet_send(char * out,uint16_t num)
{
  uint8_t k =0;
//  for (k=0;k<TX_PLOAD_WIDTH;k++)
//  {trbuffer.tbuffer[k+2] = out[k];}	
//  trbuffer.tbuffer[k++]=0x55;
//   trbuffer.tbuffer[k++]='W';
//   trbuffer.tbuffer[k++]='K';
  PutStringToUart2(trbuffer.tbuffer,4);
  PutStringToUart2(out,20);
  
}

//******************************************************************************************************/
//*������unsigned char Packet_receive(unsigned char* rx_buf)
//*���ܣ����ݶ�ȡ�����rx_buf���ջ�������
//******************************************************************************************************/

unsigned char conhandlePC=0;
unsigned char countbyte=0;
uint8_t Packet_receive(char* rx_buf)
{
  unsigned char revale=0;
  char temp;
//  unsigned int tempnum;
//  unsigned int SendCheckSum;
//  unsigned char i;
//  countbyte=0;
  //u8 *DataFrom;
  while(Uart2.RxIn != Uart2.RxOut)
  {
    temp = Uart2.RxBuffer[Uart2.RxOut];
    Uart2.RxOut = (Uart2.RxOut + 1) & UARTRXBUFFERLENGTH;

    switch(conhandlePC)
    {
//        case 0:if(temp==0x55)  conhandlePC=1;else conhandlePC=0;break;
//        case 1:if(temp=='A')  conhandlePC=2;else conhandlePC=0;break;
        case 0:if(temp=='D')  conhandlePC=1;else conhandlePC=0;break;  //�������������ݣ����ǿ������ݣ����¼�⣻
        case 1:if(temp=='I')  conhandlePC=2;else conhandlePC=0;break;  //�������������ݣ����ǿ������ݣ����¼�⣻
        case 2:	
        { 
          if(countbyte<20)  //�����ֽ���12
          {
	    rx_buf[countbyte++]= temp;
	  }
	  else 
	  {
            trbuffer.TF=1;
	    revale=1; 
	    countbyte=0;
	    conhandlePC=0;
            return revale;
	  }
          break; 
       }
       default :conhandlePC=0;break;
    } 
  }
  return revale;
}

