/*
 * ========================================================================
 *
 *       Filename:  Voice_Dect.h
 *
 *    Description:  
 *
 *        Version:  1.0.0
 *        Created:  2011.11.23
 *       Revision:  none
 *       Compiler:  IAR 6.01
 *            Cpu:  STM32F103RET6
 *
 *         Author:  ������ (adi)
 *          Email:  wangzengdi@gmail.com  
 *             QQ:  506064082
 *
 * ========================================================================
 */

#include "stm32_includes.h"



int32_t sum_all(int16_t *ptr, int16_t len)
{
	int32_t ret = 0;
	while(len--)
		ret += *ptr++;

	return ret;
}

int32_t aver(int16_t *ptr, int16_t len)
{
	int32_t ret = 0;
	int16_t dlen = len;
	while(dlen--)
		ret += *ptr++;

	return ret/len;
}

uint32_t aver_abs(int16_t *ptr, int16_t len)
{
	uint32_t ret = 0;
	int16_t dlen = len;
	while(dlen--){
		ret += (*ptr > 0)? *ptr: -(*ptr);
		ptr++;
	}

	return ret/len;
}

void clear_all(int16_t *ptr, int16_t len)
{
	while(len--)
		*ptr++ = 0;
}


void suppress_all(int16_t *ptr, int16_t len)
{
	while(len--)
		*ptr++ /= 2;
}
