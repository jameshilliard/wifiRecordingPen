/*
 * ========================================================================
 *
 *       Filename:  main.c
 *
 *    Description:  Main program body
 *
 *        Version:  1.0.0
 *        Created:  2011.11.16
 *       Revision:  none
 *       Compiler:  IAR 6.01
 *            Cpu:  STM32F103RET6
 *    STM32STDLIB:  STM32F10x_StdPeriph_Lib_V3.5.0
 *
 *         Author:  ������ (adi)
 *          Email:  wangzengdi@gmail.com  
 *             QQ:  506064082
 *
 * ========================================================================
 */


/* Includes ------------------------------------------------------------------*/
#include "main.h"
//#include "voice.h"
#ifdef HAVE_CONFIG_H
#include "config.h"
#endif
#include <speex/speex.h>
#include"arch.h"
#include "stm32_includes.h"

/** @addtogroup SpeexVocoder_STM32F103_STK
  * @{
  */ 




/* Private function prototypes -----------------------------------------------*/


/* Private functions ---------------------------------------------------------*/



/**
  * @brief  Main program.
  * @param  None
  * @retval : None
  */

int main(void)
{
  BSP_Init();
  FC211_AG_Init();
  Speex_Init();  
  Voice_Realtime_Endecode();
}









/**
  * @brief  Ovveride the _speex_putc function of the speex library
  * @param  None
  * @retval : None
  */
void _speex_putc(int ch, void *file)
{
  while(1)
  {
  };
}



/**
  * @brief  Ovveride the _speex_fatal function of the speex library
  * @param  None
  * @retval : None
  */
void _speex_fatal(const char *str, const char *file, int line)
{
  while(1)
  {
  };
}

#ifdef  USE_FULL_ASSERT


/**
  * @brief  Reports the name of the source file and the source line number
  *   where the assert_param error has occurred.
  * @param file: pointer to the source file name
  * @param line: assert_param error line source number
  * @retval : None
  */
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif

/**
  * @}
  */ 


/******************* (C) COPYRIGHT 2009 STMicroelectronics *****END OF FILE****/
