/*
 * ========================================================================
 *
 *       Filename:  BSP.h
 *
 *    Description:  
 *
 *        Version:  1.0.0
 *        Created:  2011.11.19
 *       Revision:  none
 *       Compiler:  IAR 5.4
 *            Cpu:  STM32F103RET6
 *    STM32STDLIB:  STM32F10x_StdPeriph_Lib_V3.5.0
 *
 *         Author:  ������ (adi)
 *          Email:  wangzengdi@gmail.com  
 *             QQ:  506064082
 *
 * ========================================================================
 */

#ifndef  __BSP_H__
#define  __BSP_H__

void BSP_Init(void);


#endif  

