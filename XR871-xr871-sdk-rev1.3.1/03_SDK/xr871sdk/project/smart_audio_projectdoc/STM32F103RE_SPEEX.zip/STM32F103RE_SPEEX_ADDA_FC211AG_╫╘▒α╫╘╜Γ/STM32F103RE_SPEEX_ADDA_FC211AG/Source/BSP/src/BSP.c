/*
 * ========================================================================
 *
 *       Filename:  BSP.c
 *
 *    Description:  
 *
 *        Version:  1.0.0
 *        Created:  2011.11.19
 *       Revision:  none
 *       Compiler:  IAR 5.4
 *            Cpu:  STM32F103RET6
 *    STM32STDLIB:  STM32F10x_StdPeriph_Lib_V3.5.0
 *
 *         Author:  ������ (adi)
 *          Email:  wangzengdi@gmail.com  
 *             QQ:  506064082
 *
 * ========================================================================
 */

#include "stm32_includes.h"

/*
*********************************************************************************************************
*                                           LOCAL CONSTANTS
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                          LOCAL DATA TYPES
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                            LOCAL TABLES
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                       LOCAL GLOBAL VARIABLES
*********************************************************************************************************
*/


/*
*********************************************************************************************************
*                                      LOCAL FUNCTION PROTOTYPES
*********************************************************************************************************
*/


static  void  RCC_Configuration      (void);
static  void  NVIC_Configuration     (void);
static  void  GPIO_Configuration     (void);
static  void  USART2_Configuration   (void);
//static  void  EXIT_Configuration     (void);
//static  void  tim_interrupt_config   (void);
//static  void  Tmr_TickInit           (void);

/**
  * @brief  Initializes the demonstration application.
  * @param  None
  * @retval : None
  */
void BSP_Init(void)
{
  RCC_Configuration();
  GPIO_Configuration();
  USART2_Configuration();
  NVIC_Configuration();
}

void RCC_Configuration(void)
{
//  SystemInit();
  ErrorStatus HSEStartUpStatus;
  
  /* RCC system reset(for debug purpose) */
  RCC_DeInit();

  /* Enable HSE */
  RCC_HSEConfig(RCC_HSE_ON);

  /* Wait till HSE is ready */
  HSEStartUpStatus = RCC_WaitForHSEStartUp();

  if (HSEStartUpStatus == SUCCESS)
  {
    /* Enable Prefetch Buffer */
    FLASH_PrefetchBufferCmd(FLASH_PrefetchBuffer_Enable);

    /* Flash 2 wait state */
    FLASH_SetLatency(FLASH_Latency_2);

    /* HCLK = SYSCLK */
    RCC_HCLKConfig(RCC_SYSCLK_Div1);

    /* PCLK2 = HCLK */
    RCC_PCLK2Config(RCC_HCLK_Div1);

    /* PCLK1 = HCLK/2 */
    RCC_PCLK1Config(RCC_HCLK_Div2);

    /* PLLCLK = 8MHz * 9 = 72 MHz */
    RCC_PLLConfig(RCC_PLLSource_HSE_Div1, RCC_PLLMul_9);

    /* Enable PLL */
    RCC_PLLCmd(ENABLE);

    /* Wait till PLL is ready */
    while (RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET)
    {}

    /* Select PLL as system clock source */
    RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);

    /* Wait till PLL is used as system clock source */
    while (RCC_GetSYSCLKSource() != 0x08)
    {}
  }
  
  /* TIM2 and TIM3 clocks enable */
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2 | RCC_APB1Periph_TIM3 , ENABLE);
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_DAC, ENABLE);
   /* Enable GPIOA, GPIOC, ADC1 , AFIO and TIM1 clock */
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1 | RCC_APB2Periph_GPIOA| RCC_APB2Periph_GPIOB | RCC_APB2Periph_GPIOC | RCC_APB2Periph_AFIO, ENABLE);

  /* Interrupt Configuration */
    /* USART2 configuration -------------------------------------------------------*/
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2 ,ENABLE);  
}


void GPIO_Configuration (void)
{
  /* Configure USART3 Tx as alternate function push-pull */
//  GPIO_PinRemapConfig(GPIO_FullRemap_TIM2,ENABLE);
  GPIO_InitTypeDef GPIO_InitStructure;
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
    
  /* Configure USART3 Rx as input floating */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOA, &GPIO_InitStructure);  
}

void USART2_Configuration (void)
{
  /*-- USART2 configured as follow:------------------------
        - Word Length = 8 Bits
        - 1 Stop Bit
        - No parity
        - BaudRate = 9600 baud
        - Receive and transmit enabled
  -------------------------------------------------------*/  
  USART_InitTypeDef USART_InitStructure;
  USART_ClockInitTypeDef USART_ClockIni;
  
  USART_InitStructure.USART_BaudRate = 19200;
  USART_InitStructure.USART_WordLength = USART_WordLength_8b;
  USART_InitStructure.USART_StopBits = USART_StopBits_1;
  USART_InitStructure.USART_Parity = USART_Parity_No;
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
  
  USART_ClockIni.USART_Clock = USART_Clock_Disable;
  USART_ClockIni.USART_CPOL = USART_CPOL_Low;
  USART_ClockIni.USART_CPHA = USART_CPHA_2Edge;
  USART_ClockIni.USART_LastBit = USART_LastBit_Disable;


  /* USART configuration */
  USART_Init(USART2, &USART_InitStructure);
  USART_ClockInit(USART2,&USART_ClockIni);
  USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);
//  USART_ITConfig(USART3, USART_IT_TXE, DISABLE);//
  USART_Cmd(USART2, ENABLE);
}

  /**
  * @brief  Configures the used IRQ Channels and sets their priority.
  * @param  None
  * @retval : None
  */
void NVIC_Configuration(void)
{ 
//  NVIC_InitTypeDef NVIC_InitStructure;
   /* 1 bit for pre-emption priority, 3 bits for subpriority */
//  NVIC_SetPriorityGrouping(6); 

	 /* Enable the TIM2 Interrupt */
//  NVIC_SetPriority(TIM2_IRQn, 0x00); /* 0x00 = 0x01 << 3 | (0x00 & 0x7*/
//  NVIC_EnableIRQ(TIM2_IRQn);
NVIC_InitTypeDef NVIC_InitStructure;

#ifdef  VECT_TAB_RAM 
  /* Set the Vector Table base location at 0x20000000 */
  NVIC_SetVectorTable(NVIC_VectTab_RAM, 0x0);
#else  /* VECT_TAB_FLASH  */
  /* Set the Vector Table base location at 0x08000000 */
  NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x0);  
#endif

/* Configure the NVIC Preemption Priority Bits */ 
  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
/* Enable the USART1 Interrupt */
  NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);

  NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
  /* Enable the TIM3 Interrupt */
 	 /* Enable the TIM2 Interrupt */
//  NVIC_SetPriority(TIM3_IRQn, 0x00); /* 0x00 = 0x01 << 3 | (0x00 & 0x7*/
//  NVIC_EnableIRQ(TIM3_IRQn);
}


