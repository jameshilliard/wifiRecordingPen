/*
 * ========================================================================
 *
 *       Filename:  stm32_includes.h
 *
 *    Description:  
 *
 *        Version:  1.0.0
 *        Created:  2011.11.16
 *       Revision:  none
 *       Compiler:  IAR 6.01
 *            Cpu:  STM32F103RET6
 *
 *         Author:  ������ (adi)
 *          Email:  wangzengdi@gmail.com  
 *             QQ:  506064082
 *
 * ========================================================================
 */

#ifndef _Stm32_includes_h
#define _Stm32_includes_h

#include "stm32f10x.h"
#include "stm32f10x_conf.h"
#include "BitBand.h"

#include <speex/speex_preprocess.h>  
#include <speex/speex_echo.h> 

#include "BSP.h"
#include "uartdriver.h"
#include "fc211_ag.h"
#include "Voice_Dect.h"

#define DECODING2 1
//#define DENOISE_VAD
//#define VOICE_ENCODE
//#define MaleVoice 1
//#define ADI_DENOISE

#endif
