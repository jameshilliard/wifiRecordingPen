/*
 * ========================================================================
 *
 *       Filename:  vocoder.c
 *
 *    Description:  This file provides all the vocoder firmware functions.
 *
 *        Version:  1.0.0
 *        Created:  2011.11.23
 *       Revision:  none
 *       Compiler:  IAR 5.4
 *            Cpu:  STM32F103RET6
 *    STM32STDLIB:  STM32F10x_StdPeriph_Lib_V3.5.0
 *
 *         Author:  ������ (adi)
 *          Email:  wangzengdi@gmail.com  
 *             QQ:  506064082
 *
 * ========================================================================
 */

/* Includes ------------------------------------------------------------------*/
#include "vocoder.h"
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "voice.h"
#ifdef HAVE_CONFIG_H
#include "config.h"
#endif
#include <speex/speex.h>
#include"arch.h"
#include "stm32_includes.h"

#define MaleVoice
#define MaleTrans

/** @addtogroup SpeexVocoder_STM32F103_STK
  * @{
  */ 


/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
#define ALL_FRAMES      300   /* the encoded male voice length */


/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
__IO int16_t IN_Buffer[2][FRAME_SIZE];
__IO int16_t OUT_Buffer[3][FRAME_SIZE];
__IO int16_t *inBuffer = IN_Buffer[0];
__IO int16_t *outBuffer = OUT_Buffer[0];
uint32_t Flash_Address = RECORDING_START_ADDRESS;
__IO uint8_t Start_Encoding = 0;
__IO uint8_t Start_Decoding=0;
__IO uint8_t Start_Playing = 0;
__IO uint8_t Recording = 0;
__IO uint8_t Playing =0;
uint32_t Encoded_Frames=0;

//SpeexBits bits;/* Holds bits so they can be read and written by the Speex routines */
SpeexBits bitsEncode;  
SpeexBits bitsDecode; 
SpeexPreprocessState * m_st;  
SpeexEchoState *echo_state; 

void *enc_state, *dec_state;/* Holds the states of the encoder & the decoder */
int quality = 4, complexity=1, vbr=0, enh=1;/* SPEEX PARAMETERS, MUST REMAINED UNCHANGED */
int denoise = 1, noiseSuppress = -25; /*noiseSuppress Preprocess*/
int vad = 1, vadProbStart = 80, vadProbContinue = 65; /* ������� */

char out_bytes[ENCODED_FRAME_SIZE];
char input_bytes[ENCODED_FRAME_SIZE];
uint16_t sample_index = 0;
__IO uint16_t NB_Frames=0;
uint8_t *pFlash = (uint8_t*)RECORDING_START_ADDRESS;


__IO uint32_t dly;
uint16_t ADCValue;

void male_voice_test(void);
void male_voice_trans_test(void);

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/


/**
  * @brief  Initializes the speex codec
  * @param  None
  * @retval : None
  */
void Speex_Init(void)
{
  speex_bits_init(&bitsEncode);  
  speex_bits_init(&bitsDecode);
#ifdef DENOISE_VAD
  m_st=speex_preprocess_state_init(160, 8000);  
  /* ���� */
  speex_preprocess_ctl(m_st, SPEEX_PREPROCESS_SET_DENOISE, &denoise); //����  
  speex_preprocess_ctl(m_st, SPEEX_PREPROCESS_SET_NOISE_SUPPRESS, &noiseSuppress); //����������dB
  /* ������� */
  speex_preprocess_ctl(m_st, SPEEX_PREPROCESS_SET_VAD, &vad); //�������  
  speex_preprocess_ctl(m_st, SPEEX_PREPROCESS_SET_PROB_START , &vadProbStart); //Set probability required for the VAD to go from silence to voice   
  speex_preprocess_ctl(m_st, SPEEX_PREPROCESS_SET_PROB_CONTINUE, &vadProbContinue); //Set probability required for the VAD to stay in the voice state (integer percent) 
#endif
  /* Speex encoding initializations */ 
//  speex_bits_init(&bits);
  enc_state = speex_encoder_init(&speex_nb_mode);
  speex_encoder_ctl(enc_state, SPEEX_SET_VBR, &vbr);
  speex_encoder_ctl(enc_state, SPEEX_SET_QUALITY,&quality);
  speex_encoder_ctl(enc_state, SPEEX_SET_COMPLEXITY, &complexity);
  /* speex decoding intilalization */
  dec_state = speex_decoder_init(&speex_nb_mode);
  speex_decoder_ctl(dec_state, SPEEX_SET_ENH, &enh);
}


/**
  * @brief  Initializes Voice recording/playing
  * @param  None
  * @retval : None.
  */
void Vocoder_Init(void)
{
  /* Peripherals InitStructure define -----------------------------------------*/
  GPIO_InitTypeDef GPIO_InitStructure;
  ADC_InitTypeDef ADC_InitStructure;
  TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
  TIM_OCInitTypeDef  TIM_OCInitStructure;

  /* ADC configuration --------------------------------------------------------*/
  
  /* ADC Channel 1 pin configuration */
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_InitStructure.GPIO_Speed = (GPIOSpeed_TypeDef)0;
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
     
  /* ADC1 structre initialization */
//  ADC_InitStructure.ADC_Resolution = ADC_Resolution_12b;
  ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;
  ADC_InitStructure.ADC_ScanConvMode = DISABLE;
  ADC_InitStructure.ADC_ContinuousConvMode = DISABLE;
  ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;
  ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Left;
  ADC_InitStructure.ADC_NbrOfChannel = 1;
  ADC_Init(ADC1, &ADC_InitStructure);

  /* ADC1 regular channel1 configuration */ 
  ADC_RegularChannelConfig(ADC1, ADC_Channel_6, 1, ADC_SampleTime_1Cycles5);
  
  /* Enable ADC1 */
  ADC_Cmd(ADC1, ENABLE);

  /* Enable ADC1 reset calibaration register */   
  ADC_ResetCalibration(ADC1);
  /* Check the end of ADC1 reset calibration register */
  while(ADC_GetResetCalibrationStatus(ADC1));

  /* Start ADC1 calibaration */
  ADC_StartCalibration(ADC1);
  /* Check the end of ADC1 calibration */
  while(ADC_GetCalibrationStatus(ADC1));

  //��DAC����TIM1��pwm�������������Ƶ���������
  /* DAC1 configuration -------------------------------------------------------*/
//  GPIO_InitTypeDef GPIO_InitStructure;

  /* Once the DAC channel is enabled, the corresponding GPIO pin is automatically 
     connected to the DAC converter. In order to avoid parasitic consumption, 
     the GPIO pin should be configured in analog */
  GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_4;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
  
  DAC_InitTypeDef  DAC_InitStructure;
  /* DAC Periph clock enable */

  
  /* DAC channel1 Configuration */
  DAC_InitStructure.DAC_Trigger = DAC_Trigger_None;
  DAC_InitStructure.DAC_WaveGeneration = DAC_WaveGeneration_None;
  DAC_InitStructure.DAC_LFSRUnmask_TriangleAmplitude = 0;
  DAC_InitStructure.DAC_OutputBuffer = DAC_OutputBuffer_Enable;
  DAC_Init(DAC_Channel_1, &DAC_InitStructure);
  
  DAC_Cmd(DAC_Channel_1, ENABLE);
  
  /* TIM2 configuration -------------------------------------------------------*/
  TIM_DeInit(TIM2);
  TIM_OCStructInit(&TIM_OCInitStructure);
  TIM_TimeBaseStructInit(&TIM_TimeBaseStructure);
  /* TIM2 used for timing, the timing period depends on the sample rate */
  TIM_TimeBaseStructure.TIM_Prescaler = 0x00;    /* TIM2CLK = 72 MHz */
  TIM_TimeBaseStructure.TIM_Period = TIM2ARRValue;
  TIM_TimeBaseStructure.TIM_ClockDivision = 0x0;
  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
  TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);
  
  /* Output Compare Inactive Mode configuration: Channel1 */
  TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_Inactive;
  TIM_OCInitStructure.TIM_Pulse = 0x0;
  TIM_OC1Init(TIM2, &TIM_OCInitStructure);
  TIM_OC1PreloadConfig(TIM2, TIM_OCPreload_Disable);
  
  /* TIM3 configuration -------------------------------------------------------*/
  
  TIM_DeInit(TIM3);
  TIM_OCStructInit(&TIM_OCInitStructure);
  TIM_TimeBaseStructInit(&TIM_TimeBaseStructure);
  /* TIM3 used for timing, the timing period depends on the sample rate */
  TIM_TimeBaseStructure.TIM_Prescaler = 0x00;    /* TIM3CLK = 72 MHz */
  TIM_TimeBaseStructure.TIM_Period = TIM3ARRValue;
  TIM_TimeBaseStructure.TIM_ClockDivision = 0x0;
  TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
  TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);
  
  /* Output Compare Inactive Mode configuration: Channel1 */
  TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_Inactive;
  TIM_OCInitStructure.TIM_Pulse = 0x0;
  TIM_OC1Init(TIM3, &TIM_OCInitStructure);
  TIM_OC1PreloadConfig(TIM3, TIM_OCPreload_Disable);


  
}



/**
  * @brief  Start playing
  * @param  None
  * @retval : None
  */
void Vocoder_Start(void)
{
  /* ADC1 regular Software Start Conv */ 
  ADC_SoftwareStartConvCmd(ADC1, ENABLE);

  /* TIM1 counter enable */
//  TIM_Cmd(TIM1, ENABLE);
  /* TIM1 Main Output Enable */
//  TIM_CtrlPWMOutputs(TIM1, ENABLE);

  /* Relaod ARR register */
  TIM2->ARR = TIM2ARRValue;
  
  /* Enable the TIM Counter */
  TIM2->CR1 |= CR1_CEN_Set;

  /* Clear the IT pending Bit */
  TIM2->SR = (uint16_t)TIM_INT_Update;

  /* Enable TIM2 update interrupt */
  TIM2->DIER |= TIM_IT_Update;

  /* Only for OLIMEX STM32F103-STK board --------------------------------------*/
  /* TS4871 on */
//  GPIO_WriteBit(GPIOC, GPIO_Pin_3, Bit_RESET);

}



/**
  * @brief  Stop vocoder 
  * @param  None
  * @retval : None
  */
void Vocoder_Stop(void)
{
  /* ADC1 regular Software Stop Conv */ 
  ADC_SoftwareStartConvCmd(ADC1, DISABLE);

  /* TIM1 counter enable */
//  TIM_Cmd(TIM1, DISABLE);
  /* TIM1 Main Output Enable */
//  TIM_CtrlPWMOutputs(TIM1, DISABLE);

  /* Stop TIM2 */
  TIM_Cmd(TIM2, DISABLE);

  /* Disable TIM2 update interrupt */
  TIM_ITConfig(TIM2, TIM_IT_Update, DISABLE);

  /* Only for OLIMEX STM32F103-STK board --------------------------------------*/
  /* TS4871 off */
//  GPIO_WriteBit(GPIOC, GPIO_Pin_3, Bit_SET);

}



/**
  * @brief  Erases the FLASH recording area
  * @param  None
  * @retval : None
  */
void Voice_Recording_Init(void)
{
  uint32_t page_nbr;
  FLASH_Status FLASHStatus = FLASH_COMPLETE;

  /* Flash unlock */
  FLASH_Unlock();

  /* Erase the needed pages where the user recorded voice will be loaded */
  for(page_nbr = 0; (page_nbr < ALL_PAGES) && (FLASHStatus == FLASH_COMPLETE); page_nbr++)
  {
     FLASHStatus = FLASH_ErasePage(RECORDING_START_ADDRESS + (PAGE_SIZE * page_nbr));
  }

}



/**
  * @brief  Start voice recording
  * @param  None
  * @retval : None
  */
void Voice_Recording_Start(void)
{
  /* TS4871 off */
  GPIO_WriteBit(GPIOC, GPIO_Pin_3, Bit_SET);

  /* ADC1 regular Software Start Conv */ 
  ADC_SoftwareStartConvCmd(ADC1, ENABLE);

  /* Relaod ARR register */
  TIM3->ARR = TIM3ARRValue;
  
  /* Enable the TIM Counter */
  TIM3->CR1 |= CR1_CEN_Set;

  /* Clear the IT pending Bit */
  TIM3->SR = (uint16_t)TIM_INT_Update;

  /* Enable TIM3 update interrupt */
  TIM3->DIER |= TIM_IT_Update;
  
}



/**
  * @brief  Start voice playing
  * @param  None
  * @retval : None
  */
void Voice_Playing_Start(void)
{  
  /* TIM1 counter enable */
  TIM_Cmd(TIM1, ENABLE);

  /* TIM1 Main Output Enable */
  TIM_CtrlPWMOutputs(TIM1, ENABLE);
  
  /* Relaod ARR register */
  TIM3->ARR = TIM3ARRValue;
  
  /* Enable the TIM Counter */
  TIM3->CR1 |= CR1_CEN_Set;

  /* Clear the IT pending Bit */
  TIM3->SR = (uint16_t)TIM_INT_Update;

  /* Enable TIM3 update interrupt */
  TIM3->DIER |= TIM_IT_Update;
  
  /* Only for OLIMEX STM32F103-STK board --------------------------------------*/
  /* TS4871 on */
  GPIO_WriteBit(GPIOC, GPIO_Pin_3, Bit_RESET);
}



/**
  * @brief  Stop voice recording
  * @param  None
  * @retval : None
  */
void Voice_Recording_Stop(void)
{
  /* ADC1 regular Software Stop Conv */ 
  ADC_SoftwareStartConvCmd(ADC1, DISABLE);

  /* Stop TIM3 */
  TIM_Cmd(TIM3, DISABLE);

  /* Clear the IT pending Bit */
  TIM3->SR = (uint16_t)TIM_INT_Update;

  /* Disable TIM3 update interrupt */
  TIM_ITConfig(TIM3, TIM_IT_Update, DISABLE);

  /* Only for OLIMEX STM32F103-STK board --------------------------------------*/
  /* TS4871 off */
  GPIO_WriteBit(GPIOC, GPIO_Pin_3, Bit_SET);
}

void Voice_Realtime_Endecode(void)
{
    packhead(); 
    static uint8_t Decoding_spin=0;
    uint32_t aver = 0, aver_last = 0;
    uint8_t act_period = 0;

    male_voice_test();
    male_voice_trans_test();

    Vocoder_Init();
    Vocoder_Start();
    Start_Playing = REAL_VOICE;

    Uart2.RxIn = 0;
    Uart2.RxOut= 0;
    while(1)
    {

#ifdef VOICE_ENCODE
      
      if(Start_Encoding == 1)
      {       
        {  
          /* Flush all the bits in the struct so we can encode a new frame */
          speex_bits_reset(&bitsEncode);
          /* Encode the frame */
          speex_encode_int(enc_state, (spx_int16_t*)IN_Buffer[0], &bitsEncode);
          /* Copy the bits to an array of char that can be decoded */
          speex_bits_write(&bitsEncode, (char *)out_bytes, ENCODED_FRAME_SIZE);
        
          Packet_send(out_bytes,ENCODED_FRAME_SIZE);

          Start_Encoding = 0;	
        } 
      }      

      else if(Start_Encoding == 2)
      {       
        {  
          /* Flush all the bits in the struct so we can encode a new frame */
          speex_bits_reset(&bitsEncode);
          /* Encode the frame */
          speex_encode_int(enc_state, (spx_int16_t*)IN_Buffer[1], &bitsEncode);
          /* Copy the bits to an array of char that can be decoded */
          speex_bits_write(&bitsEncode, (char *)out_bytes, ENCODED_FRAME_SIZE);
        
          Packet_send(out_bytes,ENCODED_FRAME_SIZE);

          Start_Encoding = 0;	
        } 
      }
#endif      
      /*else*/ if(Packet_receive(input_bytes))
      {
#ifdef DECODING2
        Decoding_spin=Decoding_spin^1;
         if(Start_Decoding == 1)//if(Decoding_spin)//
         {
            /* Copy the encoded data into the bit-stream struct */
            speex_bits_read_from(&bitsDecode, (char *)input_bytes, ENCODED_FRAME_SIZE);
            /* Decode the data */
            speex_decode_int(dec_state, &bitsDecode, (spx_int16_t*)OUT_Buffer[0]);
            /* Signal the end of the decoding */
            Start_Decoding = 0;
         }
         else if(Start_Decoding == 2)//else 
         {
            /* Copy the encoded data into the bit-stream struct */
            speex_bits_read_from(&bitsDecode, (char *)input_bytes, ENCODED_FRAME_SIZE);
            /* Decode the data */
            speex_decode_int(dec_state, &bitsDecode, (spx_int16_t*)OUT_Buffer[1]);
            /* Signal the end of the decoding */
            Start_Decoding = 0;
         }
#else
         switch(Decoding_spin)//���ģ��޸ĳ�3����� 20111119
         {
            case 0:
              {Decoding_spin = 1;    
                /* Copy the encoded data into the bit-stream struct */
                speex_bits_read_from(&bits, (char *)input_bytes, ENCODED_FRAME_SIZE);
                /* Decode the data */
                speex_decode_int(dec_state, &bits, (spx_int16_t*)OUT_Buffer[2]);
                /* Signal the end of the decoding */
                Start_Decoding = 0;
                break;
              }
            case 1:
              {Decoding_spin = 2;    
                /* Copy the encoded data into the bit-stream struct */
                speex_bits_read_from(&bits, (char *)input_bytes, ENCODED_FRAME_SIZE);
                /* Decode the data */
                speex_decode_int(dec_state, &bits, (spx_int16_t*)OUT_Buffer[1]);
                /* Signal the end of the decoding */
                Start_Decoding = 0;
                break;
              }
            case 2:
              {Decoding_spin = 0;    
                /* Copy the encoded data into the bit-stream struct */
                speex_bits_read_from(&bits, (char *)input_bytes, ENCODED_FRAME_SIZE);
                /* Decode the data */
                speex_decode_int(dec_state, &bits, (spx_int16_t*)OUT_Buffer[0]);
                /* Signal the end of the decoding */
                Start_Decoding = 0;
                break;
              }
            default :Decoding_spin=0;break;
        }
#endif
      }
    }
}

void male_voice_trans_test(void)
{
  #ifdef MaleVoice
    Start_Playing = REAL_VOICE;
    Vocoder_Init();
  
    /* we prepare two buffers of decoded data: */
    /* the first one, */
    int i;
    for(i=0;i<ENCODED_FRAME_SIZE; i++)
    {
      out_bytes[i] = male_voice[sample_index++];
    } 
    
#ifdef MaleTrans      
    Packet_send(out_bytes,ENCODED_FRAME_SIZE);  
//    if(Packet_receive(input_bytes))
#endif
      
//    { 
      
#ifdef MaleTrans
//    speex_bits_read_from(&bits, input_bytes, ENCODED_FRAME_SIZE);
#else
//    speex_bits_read_from(&bits, out_bytes, ENCODED_FRAME_SIZE);
#endif
    
//    speex_decode_int(dec_state, &bits, (spx_int16_t*)OUT_Buffer[0]);
//    }
    /* and the second one. */
    for(i=0;i<ENCODED_FRAME_SIZE; i++)
    {
      out_bytes[i] = male_voice[sample_index++];
    } 
    
#ifdef MaleTrans      
    Packet_send(out_bytes,ENCODED_FRAME_SIZE);  
//    if(Packet_receive(input_bytes))
#endif
      
//    { 
      
#ifdef MaleTrans
//    speex_bits_read_from(&bits, input_bytes, ENCODED_FRAME_SIZE);
#else
//    speex_bits_read_from(&bits, out_bytes, ENCODED_FRAME_SIZE);
#endif
//    speex_decode_int(dec_state, &bits, (spx_int16_t*)OUT_Buffer[1]);
//    }
    NB_Frames++;

    Vocoder_Start();
  
    /* Now we wait until the playing of the buffers to re-decode ...*/
    while((NB_Frames < ALL_FRAMES))
    {
      if(Start_Decoding == 1) /* we start decoding the first buffer */
      {
        for(i=0;i<ENCODED_FRAME_SIZE; i++)
        {
          out_bytes[i] = male_voice[sample_index++];
        }
    
#ifdef MaleTrans      
        Packet_send(out_bytes,ENCODED_FRAME_SIZE);  
//        if(Packet_receive(input_bytes))
#endif
      
//        { 
      
#ifdef MaleTrans
//        speex_bits_read_from(&bits, input_bytes, ENCODED_FRAME_SIZE);
#else
//       speex_bits_read_from(&bits, out_bytes, ENCODED_FRAME_SIZE);
#endif
        /* Decode the data */
//        speex_decode_int(dec_state, &bits, (spx_int16_t*)OUT_Buffer[0]);
//        }
        
        Start_Decoding = 0;
        NB_Frames++;
      }
      if(Start_Decoding == 2) /* we start decoding the second buffer */
      {
        for(i=0;i<ENCODED_FRAME_SIZE; i++)
        {
          out_bytes[i] = male_voice[sample_index++];
        }
    
#ifdef MaleTrans      
        Packet_send(out_bytes,ENCODED_FRAME_SIZE);  
//        if(Packet_receive(input_bytes))
#endif
      
//        { 
      
#ifdef MaleTrans
//        speex_bits_read_from(&bits, input_bytes, ENCODED_FRAME_SIZE);
#else
//        speex_bits_read_from(&bits, out_bytes, ENCODED_FRAME_SIZE);
#endif
        /* Decode the data */
//        speex_decode_int(dec_state, &bits, (spx_int16_t*)OUT_Buffer[1]);
//        }
        
        Start_Decoding = 0;
        NB_Frames++;
      }
    }
    
    sample_index = 0;
    NB_Frames = 0;
    inBuffer = IN_Buffer[0];
    outBuffer = OUT_Buffer[0];
    Vocoder_Stop();
#endif  

}
    
void male_voice_test(void)
{
    Start_Playing = REAL_VOICE;
    Vocoder_Init();
  
    /* we prepare two buffers of decoded data: */
    /* the first one, */
    int i;
    for(i=0;i<ENCODED_FRAME_SIZE; i++)
    {
      out_bytes[i] = male_voice[sample_index++];
    } 

    speex_bits_read_from(&bitsDecode, out_bytes, ENCODED_FRAME_SIZE);
    
    speex_decode_int(dec_state, &bitsDecode, (spx_int16_t*)OUT_Buffer[0]);

    /* and the second one. */
    for(i=0;i<ENCODED_FRAME_SIZE; i++)
    {
      out_bytes[i] = male_voice[sample_index++];
    } 

    speex_bits_read_from(&bitsDecode, out_bytes, ENCODED_FRAME_SIZE);

    speex_decode_int(dec_state, &bitsDecode, (spx_int16_t*)OUT_Buffer[1]);

    NB_Frames++;

    Vocoder_Start();
  
    /* Now we wait until the playing of the buffers to re-decode ...*/
    while((NB_Frames < ALL_FRAMES))
    {
      if(Start_Decoding == 1) /* we start decoding the first buffer */
      {
        for(i=0;i<ENCODED_FRAME_SIZE; i++)
        {
          out_bytes[i] = male_voice[sample_index++];
        }
        speex_bits_read_from(&bitsDecode, out_bytes, ENCODED_FRAME_SIZE);
        /* Decode the data */
        speex_decode_int(dec_state, &bitsDecode, (spx_int16_t*)OUT_Buffer[0]);
        
        Start_Decoding = 0;
        NB_Frames++;
      }
      if(Start_Decoding == 2) /* we start decoding the second buffer */
      {
        for(i=0;i<ENCODED_FRAME_SIZE; i++)
        {
          out_bytes[i] = male_voice[sample_index++];
        }     
        { 
        speex_bits_read_from(&bitsDecode, out_bytes, ENCODED_FRAME_SIZE);
        /* Decode the data */
        speex_decode_int(dec_state, &bitsDecode, (spx_int16_t*)OUT_Buffer[1]);
        }
        
        Start_Decoding = 0;
        NB_Frames++;
      }
    }
    sample_index = 0;
    NB_Frames = 0;
    inBuffer = IN_Buffer[0];
    outBuffer = OUT_Buffer[0];
    Vocoder_Stop();
}
/**
  * @}
  */ 


/******************* (C) COPYRIGHT 2009 STMicroelectronics *****END OF FILE****/
